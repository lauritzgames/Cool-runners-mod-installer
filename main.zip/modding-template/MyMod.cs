using CoolTaggerModdingAPI;

public class MyMod : IMod
{
    public void Initialize(ModAPI api)
    {
        api.RegisterObject(id: "BasicHat", data: "Name:CoolHat,Value:10");
        api.SpawnCustomObject(
            id: "CoolCube",
        position: new UnityEngine.Vector3(0f, 1f, 0f),
        scale: new UnityEngine.Vector3(1f, 2f, 1f),
        color: new UnityEngine.Color(0f, 1f, 0f, 1f));

    }

    public void OnEvent(string eventName, object eventData)
    {
    }
}
