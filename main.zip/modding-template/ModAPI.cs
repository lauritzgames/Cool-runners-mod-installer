using System;
using System.Collections.Generic;
using UnityEngine;

namespace CoolTaggerModdingAPI
{
    public sealed class ModAPI
    {
        private static readonly ModAPI _instance = new ModAPI();
        public static ModAPI Instance => _instance;

        private ModAPI() { }

        // Object registry for demo purposes
        private readonly Dictionary<string, GameObject> _registeredObjects = new Dictionary<string, GameObject>();

        public void RegisterObject(string id, string data)
        {
            Dictionary<string, string> parsedData = ParseData(data);

            string name = parsedData.ContainsKey("Name") ? parsedData["Name"] : id;
            GameObject obj = new GameObject(name);

            if (parsedData.TryGetValue("Value", out string valueStr) && float.TryParse(valueStr, out float value))
            {
                var dataComp = obj.AddComponent<ObjectData>();
                dataComp.id = id;
                dataComp.value = value;
            }

            _registeredObjects[id] = obj;

            Debug.Log($"[ModAPI] Spawned GameObject '{name}' with id='{id}' and value={parsedData.GetValueOrDefault("Value")}");
        }

        /// <summary>
        /// Creates a visible cube GameObject with custom position, scale, and color,
        /// destroying any previously registered object with the same id.
        /// </summary>
        public GameObject SpawnCustomObject(string id, Vector3 position, Vector3 scale, Color color)
        {
            // Destroy previous object if it exists
            if (_registeredObjects.TryGetValue(id, out GameObject oldObj))
            {
                UnityEngine.Object.Destroy(oldObj);
                _registeredObjects.Remove(id);
            }

            // Create visible cube primitive
            GameObject obj = GameObject.CreatePrimitive(PrimitiveType.Cube);
            obj.name = id;

            // Set position and scale
            obj.transform.position = position;
            obj.transform.localScale = scale;

            // Set color
            var renderer = obj.GetComponent<Renderer>();
            if (renderer != null)
            {
                // Use a new material instance to avoid modifying shared material
                renderer.material = new Material(renderer.material);
                renderer.material.color = color;
            }

            // Attach ObjectData component
            var dataComp = obj.AddComponent<ObjectData>();
            dataComp.id = id;
            dataComp.value = 1f; // default value

            // Register the new object
            _registeredObjects[id] = obj;

            Debug.Log($"[ModAPI] Spawned visible object '{id}' at {position} with scale {scale} and color {color}");

            return obj;
        }

        private Dictionary<string, string> ParseData(string data)
        {
            var dict = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            var pairs = data.Split(',');

            foreach (var pair in pairs)
            {
                var kv = pair.Split(':');
                if (kv.Length == 2)
                {
                    dict[kv[0].Trim()] = kv[1].Trim();
                }
            }

            return dict;
        }

        public string GetVersion() => "1.0.0";
    }

    public interface IMod
    {
        void Initialize(ModAPI api);
        void OnEvent(string eventName, object eventData);
    }

    // ✅ INCLUDED: ObjectData component
    public class ObjectData : MonoBehaviour
    {
        public string id;
        public float value;

        private void Start()
        {
            Debug.Log($"[ObjectData] Attached to GameObject: id={id}, value={value}");
        }
    }
}
